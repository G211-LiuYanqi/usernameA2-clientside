/*
 Navicat Premium Data Transfer

 Source Server         : mysql5.1.17
 Source Server Type    : MySQL
 Source Server Version : 50712
 Source Host           : localhost:3308
 Source Schema         : shopmng

 Target Server Type    : MySQL
 Target Server Version : 50712
 File Encoding         : 65001

 Date: 02/10/2024 14:45:05
*/

SET NAMES utf8mb4;
SET FOREIGN_KEY_CHECKS = 0;

-- ----------------------------
-- Table structure for caigou
-- ----------------------------
DROP TABLE IF EXISTS `caigou`;
CREATE TABLE `caigou`  (
  `cid` int(11) NOT NULL AUTO_INCREMENT COMMENT 'd',
  `goodsname` varchar(30) CHARACTER SET utf8 COLLATE utf8_general_ci NULL DEFAULT NULL,
  `price` varchar(20) CHARACTER SET utf8 COLLATE utf8_general_ci NULL DEFAULT NULL,
  `num` varchar(30) CHARACTER SET utf8 COLLATE utf8_general_ci NULL DEFAULT NULL,
  `money` varchar(30) CHARACTER SET utf8 COLLATE utf8_general_ci NULL DEFAULT NULL,
  PRIMARY KEY (`cid`) USING BTREE
) ENGINE = InnoDB AUTO_INCREMENT = 12 CHARACTER SET = utf8 COLLATE = utf8_general_ci ROW_FORMAT = Dynamic;

-- ----------------------------
-- Records of caigou
-- ----------------------------
INSERT INTO `caigou` VALUES (9, 'material 1', '12', '50', '600');
INSERT INTO `caigou` VALUES (11, 'material 2', '18', '100', '1800');

-- ----------------------------
-- Table structure for card
-- ----------------------------
DROP TABLE IF EXISTS `card`;
CREATE TABLE `card`  (
  `cid` int(11) NOT NULL AUTO_INCREMENT COMMENT 'id',
  `gid` varchar(30) CHARACTER SET utf8 COLLATE utf8_general_ci NULL DEFAULT NULL COMMENT 'id',
  `number` int(11) NULL DEFAULT 1,
  `uid` varchar(30) CHARACTER SET utf8 COLLATE utf8_general_ci NULL DEFAULT NULL,
  PRIMARY KEY (`cid`) USING BTREE
) ENGINE = InnoDB AUTO_INCREMENT = 7 CHARACTER SET = utf8 COLLATE = utf8_general_ci ROW_FORMAT = Dynamic;

-- ----------------------------
-- Records of card
-- ----------------------------

-- ----------------------------
-- Table structure for comments
-- ----------------------------
DROP TABLE IF EXISTS `comments`;
CREATE TABLE `comments`  (
  `cid` int(11) NOT NULL AUTO_INCREMENT COMMENT '评价表id',
  `uid` varchar(11) CHARACTER SET utf8 COLLATE utf8_general_ci NULL DEFAULT NULL COMMENT '用户id',
  `gid` varchar(11) CHARACTER SET utf8 COLLATE utf8_general_ci NULL DEFAULT NULL COMMENT '商品id',
  `oid` varchar(11) CHARACTER SET utf8 COLLATE utf8_general_ci NULL DEFAULT NULL COMMENT '订单id',
  `content` varchar(100) CHARACTER SET utf8 COLLATE utf8_general_ci NULL DEFAULT NULL COMMENT '评价内容',
  `ctime` varchar(50) CHARACTER SET utf8 COLLATE utf8_general_ci NULL DEFAULT NULL,
  PRIMARY KEY (`cid`) USING BTREE
) ENGINE = InnoDB AUTO_INCREMENT = 38 CHARACTER SET = utf8 COLLATE = utf8_general_ci ROW_FORMAT = Dynamic;

-- ----------------------------
-- Records of comments
-- ----------------------------
INSERT INTO `comments` VALUES (31, '111', '7', '68', 'Good project', '2024-09-30 14:36:35');
INSERT INTO `comments` VALUES (32, '111', '1', '70', 'Good project', '2024-09-30 14:36:35');
INSERT INTO `comments` VALUES (33, '111', '4', '72', 'Good project', '2024-09-30 14:36:35');
INSERT INTO `comments` VALUES (34, '111', '9', '77', 'Good project', '2024-09-30 14:36:35');
INSERT INTO `comments` VALUES (35, '111', '1', '78', 'Good project', '2024-09-30 14:36:35');
INSERT INTO `comments` VALUES (36, '111', '1', '68', '......', '2024-09-30 14:36:35');
INSERT INTO `comments` VALUES (37, '111', '1', '68', '......', '2024-09-30 14:36:35');

-- ----------------------------
-- Table structure for goods
-- ----------------------------
DROP TABLE IF EXISTS `goods`;
CREATE TABLE `goods`  (
  `id` int(11) NOT NULL AUTO_INCREMENT COMMENT 'id',
  `type` int(11) NULL DEFAULT NULL,
  `goodsname` varchar(500) CHARACTER SET utf8 COLLATE utf8_general_ci NULL DEFAULT NULL,
  `imgs` varchar(100) CHARACTER SET utf8 COLLATE utf8_general_ci NULL DEFAULT NULL,
  `price` int(11) NULL DEFAULT NULL,
  `sid` int(11) NULL DEFAULT NULL,
  `productiondate` varchar(30) CHARACTER SET utf8 COLLATE utf8_general_ci NULL DEFAULT NULL,
  `number` varchar(30) CHARACTER SET utf8 COLLATE utf8_general_ci NULL DEFAULT NULL,
  `lirun` double(30, 2) NULL DEFAULT NULL,
  INDEX `id`(`id`) USING BTREE
) ENGINE = InnoDB AUTO_INCREMENT = 13 CHARACTER SET = utf8 COLLATE = utf8_general_ci ROW_FORMAT = Dynamic;

-- ----------------------------
-- Records of goods
-- ----------------------------
INSERT INTO `goods` VALUES (1, 1, 'Help Frequent', 'p1.jpg', 8, 1, '2024-10-01', '37', 6.00);
INSERT INTO `goods` VALUES (2, 1, 'Improving environment', 'p2.jpg', 11, 1, '2024-09-30', '47', 7.00);
INSERT INTO `goods` VALUES (3, 1, 'Improving people', 'p3.jpg', 7, 1, '2024-09-30', '150', 5.00);
INSERT INTO `goods` VALUES (9, 2, 'Provide  homeless', 'p4.jpg', 22, 1, '2024-09-30', '40', 7.00);
INSERT INTO `goods` VALUES (12, 1, 'Protecting trees', 'p5.jpg', 34, 1, '2024-10-01', '23', 3434.00);

-- ----------------------------
-- Table structure for orders
-- ----------------------------
DROP TABLE IF EXISTS `orders`;
CREATE TABLE `orders`  (
  `oid` int(11) NOT NULL AUTO_INCREMENT COMMENT 'id',
  `uid` varchar(30) CHARACTER SET utf8 COLLATE utf8_general_ci NULL DEFAULT NULL,
  `gid` varchar(30) CHARACTER SET utf8 COLLATE utf8_general_ci NULL DEFAULT NULL,
  `money` varchar(30) CHARACTER SET utf8 COLLATE utf8_general_ci NULL DEFAULT NULL,
  `num` varchar(30) CHARACTER SET utf8 COLLATE utf8_general_ci NULL DEFAULT NULL,
  `pingjia` int(11) NULL DEFAULT 0,
  PRIMARY KEY (`oid`) USING BTREE
) ENGINE = InnoDB AUTO_INCREMENT = 83 CHARACTER SET = utf8 COLLATE = utf8_general_ci ROW_FORMAT = Dynamic;

-- ----------------------------
-- Records of orders
-- ----------------------------
INSERT INTO `orders` VALUES (78, '111', '1', '24', '3', 1);
INSERT INTO `orders` VALUES (79, '111', '1', '8', '1', 0);
INSERT INTO `orders` VALUES (80, '111', '2', '11', '1', 0);
INSERT INTO `orders` VALUES (81, '111', '5', '28', '1', 0);
INSERT INTO `orders` VALUES (82, '111', '1', '16', '2', 0);

-- ----------------------------
-- Table structure for supplier
-- ----------------------------
DROP TABLE IF EXISTS `supplier`;
CREATE TABLE `supplier`  (
  `id` int(11) NOT NULL AUTO_INCREMENT COMMENT '供应商id',
  `region` varchar(30) CHARACTER SET utf8 COLLATE utf8_general_ci NULL DEFAULT NULL COMMENT '地区',
  `suppliername` varchar(30) CHARACTER SET utf8 COLLATE utf8_general_ci NULL DEFAULT NULL COMMENT '供应商',
  `tel` varchar(30) CHARACTER SET utf8 COLLATE utf8_general_ci NULL DEFAULT NULL COMMENT '电话',
  PRIMARY KEY (`id`) USING BTREE
) ENGINE = InnoDB AUTO_INCREMENT = 4 CHARACTER SET = utf8 COLLATE = utf8_general_ci ROW_FORMAT = Dynamic;

-- ----------------------------
-- Records of supplier
-- ----------------------------
INSERT INTO `supplier` VALUES (1, 'A Block', 'A Org', '2432131');
INSERT INTO `supplier` VALUES (2, 'B Block', 'B Org', '2312312323');
INSERT INTO `supplier` VALUES (3, 'C Block', 'C Org', '078821389');

-- ----------------------------
-- Table structure for type
-- ----------------------------
DROP TABLE IF EXISTS `type`;
CREATE TABLE `type`  (
  `id` int(11) NOT NULL AUTO_INCREMENT COMMENT 'id',
  `typename` varchar(30) CHARACTER SET utf8 COLLATE utf8_general_ci NULL DEFAULT NULL,
  INDEX `id`(`id`) USING BTREE
) ENGINE = InnoDB AUTO_INCREMENT = 7 CHARACTER SET = utf8 COLLATE = utf8_general_ci ROW_FORMAT = Dynamic;

-- ----------------------------
-- Records of type
-- ----------------------------
INSERT INTO `type` VALUES (1, 'Public welfare');
INSERT INTO `type` VALUES (2, 'wildlife');
INSERT INTO `type` VALUES (3, 'humanity');
INSERT INTO `type` VALUES (4, 'love');

-- ----------------------------
-- Table structure for users
-- ----------------------------
DROP TABLE IF EXISTS `users`;
CREATE TABLE `users`  (
  `uid` varchar(30) CHARACTER SET utf8 COLLATE utf8_general_ci NULL DEFAULT NULL,
  `uname` varchar(30) CHARACTER SET utf8 COLLATE utf8_general_ci NULL DEFAULT NULL,
  `upwd` varchar(30) CHARACTER SET utf8 COLLATE utf8_general_ci NULL DEFAULT NULL,
  `tel` varchar(30) CHARACTER SET utf8 COLLATE utf8_general_ci NULL DEFAULT NULL,
  `role` int(11) NULL DEFAULT 0
) ENGINE = InnoDB CHARACTER SET = utf8 COLLATE = utf8_general_ci ROW_FORMAT = Dynamic;

-- ----------------------------
-- Records of users
-- ----------------------------
INSERT INTO `users` VALUES ('111', '张三', '111', '1656488565458', 0);
INSERT INTO `users` VALUES ('admin', 'admin', 'admin', '15984546565', 1);
INSERT INTO `users` VALUES ('666', '66', '66', '66', 1);
INSERT INTO `users` VALUES ('6', '李四', '112', '18546524956', 0);
INSERT INTO `users` VALUES ('123', '小李', '123', '124844564564', 0);
INSERT INTO `users` VALUES ('456', '小李', '456', '13758469546', 0);
INSERT INTO `users` VALUES ('4587', '小李', '111', '13485796542', 0);
INSERT INTO `users` VALUES ('1212', '111', '1212444', '888', 0);
INSERT INTO `users` VALUES ('456', '111', '789', '123456', 0);
INSERT INTO `users` VALUES ('345', '111', '34', '3456', 0);
INSERT INTO `users` VALUES ('smith', '111', 'aaa', '112', 0);
INSERT INTO `users` VALUES ('121', 'bbb', '111', '2111121212', 0);

SET FOREIGN_KEY_CHECKS = 1;
