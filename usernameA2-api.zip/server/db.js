module.exports = {
  mysql: {
    host: 'localhost', //连接的数据库服务器的IP
    user: 'root',//用户名
    password: '',//密码
    database: 'shopmng',//数据库
    port: '3308'//端口
  }
}