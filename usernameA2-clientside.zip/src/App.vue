<template>
	<div class="common-layout">
		<router-view></router-view>
		<!-- <el-container>
			<el-header>
				



			</el-header>
			<el-main>
				<div style="width: 1200px;margin: 0px auto;">
					
				</div>
			</el-main>
		</el-container> -->
	</div>
</template>

<script>
	import Axios from 'axios'
	// import router from "route/index.js"
	export default { //js中 es6语法，模块 导出
		name: 'App',
		data() {
			return {
			}
		},
		created() {
		},
		methods: {

			
		}
	}
</script>

<style>
	
</style>
