<template>
	<!-- Register的组件 -->
	<div style="width: 500px; margin: 0px auto;">
		<h1 align="center" style="color: black;"><el-button type="primary" @click="shouye()">back crowd funding</el-button></h1>
		<h1 align="center" style="color: black;">Register页面</h1>
		<el-form ref="regist" :model="users" label-width="120px" class="demo-ruleForm">
			<el-form-item label="Account" required>
				<el-input v-model="users.uid" @blur='checkId'></el-input>
				<span id="ts">{{msg}}</span>
			</el-form-item>
			<el-form-item label="Password" required>
				<el-input v-model="users.upwd" type="password"></el-input>
			</el-form-item>
			<el-form-item label="telphone" required>
				<el-input v-model="users.tel"></el-input>
			</el-form-item>
			<el-form-item label="姓名" required>
				<el-input v-model="users.uname"></el-input>
			</el-form-item>
			<el-form-item label="Role" required>
				<el-radio v-model="users.role" :label="0">Normal User</el-radio>
				<el-radio v-model="users.role" :label="1">Manager</el-radio>
			</el-form-item>
			<el-form-item>
				<el-button type="primary" @click="zhuce()">Register</el-button>
				<el-button type="primary" @click="denglu()">Login</el-button>

			</el-form-item>
		</el-form>

	</div>
</template>

<script>
	import Axios from 'axios'
	import {
		ElMessage
	} from 'element-plus'
	import router from "../route/index.js"
	export default {
		name: 'Regist',
		data() {
			return {
				users: {
					role: 0
				},
				msg: ''
			}
		},
		methods: {
			checkId() { //检查Account是否重复的
				Axios.post('/shopmng/api/users/selectOne', this.users).then(res => {
					if (res.data.length == 0) {
						this.msg = 'Account可用'
					} else {
						this.msg = 'Account不可用'
					}
				});
			},
			zhuce() {
				//Register
				Axios.post('/shopmng/api/users/addUsers', this.users).then(res => {
					if (res.data.affectedRows == 1) {
						// alert('Add Success')
						ElMessage({
							message: 'RegisterSuccess',
							type: 'success',
						})
					} else {
						//alert('Add Fail')
						ElMessage.error('RegisterFail')
					}
				});
			},
			denglu() {
				router.push('/Login')
			},
			shouye(){
				router.push('/')
			},
		}
	}
</script>

<style>
	#ts {
		color: red;
	}
</style>
