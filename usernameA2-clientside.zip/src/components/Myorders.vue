<template>
	<div>
		<Index></Index>
		<div style="width: 1300px;margin:0px auto;">
			<el-table :data="orders" style="width: 100%">
				<el-table-column label="Seq" width="100">
					<template #default="scope">
						{{scope.$index+1}}
					</template>
				</el-table-column>
				<el-table-column label="Project Picture" width="230">
					<template #default="scope">
						<img :src="'http://localhost:3000/' + scope.row.imgs"
							style="width: 200px;height: 130px;" />
					</template>
				</el-table-column>
				<el-table-column label="Project Name" width="150" prop='goodsname'>
				</el-table-column>
				<el-table-column label="UserName" width="150" prop='uname'>
				</el-table-column>
				<el-table-column label="telphone" width="150" prop='tel'>
				</el-table-column>
				<el-table-column label="Project Amount" width="100" prop='price'>
				</el-table-column>
				<el-table-column label="Crowdfunding frequency" width="100" prop='num'>
				</el-table-column>
				<el-table-column label="Total Crowdfunding Amount" width="100" prop='money'>
				</el-table-column>
				<el-table-column label="Operate" min-width="100">
					<template #default="scope">
						<el-button size="small" type='daner' v-if="scope.row.pingjia != 1"
							@click="addComments(scope.row)">Comment  this Project</el-button>
					</template>
				</el-table-column>
			</el-table>
			<!-- 对话框 -->
			<el-dialog v-model="show" title="Comment " width="40%">
				<el-form :model="comments" :rules="rules" ref="comments">
					<el-form-item label="Comment  this Project" prop="content" label-width="600">
						<el-input type="textarea" :rows="2" placeholder="Please input Content" v-model="comments.content">
						</el-input>
					</el-form-item>
				</el-form>
				<template #footer>
					<span class="dialog-footer">
						<el-button @click="show = false">取消</el-button>
						<el-button type="primary" @click="addContent('comments')">确定</el-button>
					</span>
				</template>
			</el-dialog>
		</div>
	</div>
</template>

<script>
	import Index from './UserTop.vue'
	import Axios from 'axios'
	import {
		ElMessageBox,
		ElMessage
	} from 'element-plus'
	import router from "../route/index.js"
	export default {
		name: 'Myorders',
		components: {
			Index
		},
		data() {
			return {
				orders: [],
				order: {},
				comments: {},
				show: false,
				rules: {
					content: [{
						required: true,
						message: 'Please input Comment ',
						trigger: 'blur'
					}]
				}
			}
		},
		created() {
			this.getUsers();
			this.getOrders();
		},
		methods: {
			getUsers() {
				// 获取sessionstorage中的用户Infomation
				let str = sessionStorage.getItem('users')
				if (str != null) {
					//把字符串转换成对象 --- sessionStorage存的必须时字符串，所以取出来的也是字符串
					this.users = JSON.parse(str);
					return
				}
			},
			getOrders() {
				Axios.post('/shopmng/api/orders/selectMyOrdes', {
					'uid': this.users.uid
				}).then(res => {
					this.orders = res.data;
				});
			},
			addComments(val) {
				Axios.post('/shopmng/api/orders/selectOne', {
					'oid': val.oid
				}).then(res => {
					this.order = res.data[0];
					this.show = true;
					this.comments.gid = this.order.id;
					this.comments.oid = this.order.oid;
					this.comments.uid = this.order.uid;
				});
			},
			addContent(comments) {
				this.$refs[comments].validate(valid => {
					if (valid) {
						this.comments.content = this.comments.content;
						Axios.post('/shopmng/api/comments/insertComments', this.comments).then(res => {
							if (res.data.affectedRows > 0) {
								ElMessage({
									type: 'success',
									message: 'CommentSuccess！',
								});
								this.show = false;
								this.updatePingjia();
								this.getOrders();
							} else {
								ElMessage({
									type: 'info',
									message: 'CommentFail',
								})
							}
						});
					} else {
						return false
					}
				})
			},
			updatePingjia() {
				Axios.post('/shopmng/api/orders/updatePingjia', {
					'oid': this.comments.oid
				}).then(res => {
					this.orders = res.data;
				});
			}
		}
	}
</script>

<style>
</style>
