<template>
	<div>
		<Index></Index>
	
	<div style="width: 1300px;margin:0px auto;">
		<el-button  type='danger' @click="showDialog">Add 供应商</el-button>
		<el-table :data="gongying" style="width: 100%">
			<el-table-column label="Seq" width="100">
				<template #default="scope">
					{{scope.$index+1}}
				</template>
			</el-table-column>
			<el-table-column label="地区" width="150" prop='region'>
			</el-table-column>
			<el-table-column label="供应商" width="150" prop='suppliername'>
			</el-table-column>
			<el-table-column label="telphone" width="150" prop='tel'>
			</el-table-column>
			<el-table-column label="Operate" width="200">
				<template #default="scope">
					<el-button size="small" type='daner' @click="deleteSupplier(scope.row,scope.$index)">Delete </el-button>
					<el-button size="small" type='daner' @click="updateSupplier(scope.row)">Change </el-button>
				</template>
			</el-table-column>
		</el-table>
		<!-- 对话框 -->
		<el-dialog  v-model="show" :type="type" :title="title" width="40%" >
			<el-form :model="xinxi" :rules="rules" ref="xinxi">
				  <el-form-item label="地区" prop="region" label-width="600">
				  	<el-input v-model="xinxi.region" autocomplete="off"></el-input>
				  </el-form-item>
				  <el-form-item label="供应商" prop="suppliername" label-width="600">
				  	<el-input v-model="xinxi.suppliername" autocomplete="off"></el-input>
				  </el-form-item>
				  <el-form-item label="telphone" prop="tel" label-width="600">
				  	<el-input v-model="xinxi.tel" autocomplete="off"></el-input>
				  </el-form-item>
			    </el-form>
			<template #footer>
				<span class="dialog-footer">
					<el-button @click="show = false">取消</el-button>
					<el-button v-if="type == 'create'" type="primary" @click="addSupplier('xinxi')">确定</el-button>
					<el-button v-if="type == 'update'" type="primary" @click="editSupplier('xinxi')">Change </el-button>
				</span>
			</template>
		</el-dialog>
	</div>
	</div>
</template>

<script>
	import Index from './AdminTop.vue'
	import Axios from 'axios'
	import {
		ElMessageBox,
		ElMessage
	} from 'element-plus'
	import router from "../route/index.js"
	export default {
		name: 'SupplierManage',
		components: {
			Index
		},
		data() {
			return{
				gongying: [],
				xinxi: {},
				show: false,
				type: '',
				title: '',
				rules: {
					region: [{
						required: true,
						message: 'Please input 地区',
						trigger: 'blur'
					}],
					suppliername: [{
						required: true,
						message: 'Please input 供应商',
						trigger: 'blur'
					}],
					tel: [{
						required: true,
						message: 'Please input telphone',
						trigger: 'blur'
					}]
				}
			}
		},
		created() {
			this.getSupplier();
		},
		methods:{
			getSupplier() {
				Axios.post('/shopmng/api/supplier/selectAll').then(res => {
					this.gongying = res.data;
				});
			},
			deleteSupplier(obj, index) {
				ElMessageBox.confirm(
					'确认Delete 吗？', {
						confirmButtonText: '确认',
						cancelButtonText: '取消',
						type: 'warning',
					}
				).then(() => {
				  Axios.post('/shopmng/api/supplier/deleteOne', {
						'id': obj.id
					}).then(res => {
				    if (res.data.affectedRows == 1) {
				    	this.gongying.splice(index, 1);
						this.getSupplier();
				    	ElMessage({
				    		message: 'Delete Success',
				    		type: 'success',
				    	});
				    } else {
				    	ElMessage({
				    		message: 'Delete Fail',
				    	});
				    }
				  });
				
				})
			},
			updateSupplier(obj) {
				this.show = true;
				this.title = "Change 供应商Infomation";
				this.type = "update";
				Axios.post('/shopmng/api/supplier/selectOne', {
						'id': obj.id
					}).then(res => {
					this.xinxi = res.data[0];
				});
			},
			showDialog() {
				//单击时对话框可见
				this.show = true;
				this.title = "Add 供应商";
				this.type = "create";
				this.xinxi.region = '';
				this.xinxi.suppliername = '';
				this.xinxi.tel = '';
			},
			addSupplier(xinxi){
				this.$refs[xinxi].validate(valid => {
					if (valid) {
						Axios.post('/shopmng/api/supplier/add', this.xinxi).then(res => {
							if (res.data.affectedRows == 1) {
								ElMessage({
									message: 'Add Success',
									type: 'success',
								});
								this.show = false;
								this.getSupplier();
							} else {
								ElMessage.error('Add Fail')
							}
						});
					} else {
						return false
					}
				})
			},
			editSupplier(xinxi) {
				this.$refs[xinxi].validate(valid => {
					if (valid) {
						Axios.post('shopmng/api/supplier/updateInfo', this.xinxi).then(res => {
							if (res.data.affectedRows > 0) {
								ElMessage({
									type: 'success',
									message: 'Change Success',
								});
								this.show = false;
								this.getSupplier();
							} else {
								ElMessage({
									type: 'info',
									message: 'Change Fail',
								})
							}
						})
					} else {
						return false
					}
				})
			},
		}
	}
</script>

<style>
</style>
