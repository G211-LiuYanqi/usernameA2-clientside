<template>
	<div>
		<Index></Index>
	
	<div style="width: 1300px;margin:0px auto;">
		<el-button style="margin-bottom: 20px;" type='danger' @click="showDialog">Lunch Project</el-button>
		<el-table :data="shangpin" style="width: 100%">
			<el-table-column label="Seq" width="100">
				<template #default="scope">
					{{scope.$index+1}}
				</template>
			</el-table-column>
			<el-table-column label="Project Picture" width="200" aria-placeholder="choose image">
				<template #default="scope">
					<img :src="'http://localhost:3000/' + scope.row.imgs"
						style="width: 200px;height: 130px;" />
				</template>
			</el-table-column>
			<el-table-column label="Crowd Funding Type" width="100" prop='typename'>
			</el-table-column>
			<el-table-column label="Project Name" width="120" prop='goodsname'>
			</el-table-column>
			<el-table-column label="Fundraising amount" width="120" prop='price'>
			</el-table-column>
			<el-table-column label="Deadline" width="150" prop='productiondate'>
			</el-table-column>
			<el-table-column label="Organizer Address" width="100" prop='region'>
			</el-table-column>
			<el-table-column label="Organizer" width="150" prop='suppliername'>
			</el-table-column>
			<el-table-column label="Operate" width="200">
				<template #default="scope">
					<el-button size="small" type='daner' @click="deleteGoods(scope.row,scope.$index)">disabled Project</el-button>
					<el-button size="small" type='daner' @click="updateGoods(scope.row)">change Project</el-button>
				</template>
			</el-table-column>
		</el-table>
		<!-- 对话框 -->
		<el-dialog v-model="show" :type="type" :title="title" width="40%">
			<el-form :model="goods" :rules="rules" ref="goods" id="fm" method="post" enctype="multipart/form-data" >
				<el-form-item label="Organizer" prop="sid" label-width="600">
					<el-select v-model="goods.sid" placeholder="Please select ">
						<el-option v-for="(gys,index) in gongying" :label="gys.suppliername" :value="gys.id" :key="index"></el-option>
					</el-select>
				</el-form-item>
				<el-form-item label="Crowd Funding Type" prop="type" label-width="600">
					<el-select v-model="goods.type" placeholder="Please select ">
						<el-option v-for="(types,index) in categoryList" :label="types.typename" :value="types.id" :key="index"></el-option>
					</el-select>
				</el-form-item>
				<el-form-item label="Project Name" prop="goodsname" label-width="600">
					<el-input v-model="goods.goodsname" name="goodsname" autocomplete="off"></el-input>
				</el-form-item>
				<el-form-item label="Project Picture" prop="pic" label-width="600">
					<el-input type="file" id="imgs" v-model="goods.pic" autocomplete="off"></el-input>
				</el-form-item>
				<el-form-item label="Fundraising amount" prop="price" label-width="600">
					<el-input v-model="goods.price" name="price" autocomplete="off"></el-input>
				</el-form-item>
				<el-form-item label="Deadline(Y-M-D)" prop="productiondate" label-width="600">
					<el-input v-model="goods.productiondate" name="productiondate" autocomplete="off"></el-input>
				</el-form-item>
				<el-form-item label="Crowd funding Num" prop="number" label-width="600">
					<el-input v-model="goods.number" name="number" autocomplete="off"></el-input>
				</el-form-item>
				<el-form-item label="Project losses" prop="lirun" label-width="600">
					<el-input v-model="goods.lirun" name="lirun" autocomplete="off"></el-input>
				</el-form-item>
			</el-form>
			<template #footer>
				<span class="dialog-footer">
					<el-button @click="show = false">取消</el-button>
					<el-button v-if="type == 'create'" type="primary" @click="addGoods('goods')">确定</el-button>
					<el-button v-if="type == 'update'" type="primary" @click="editGoods('goods')">Change </el-button>
				</span>
			</template>
		</el-dialog>
	</div>
	</div>
</template>

<script>
	import Index from './AdminTop.vue'
	import Axios from 'axios'
	import {
		ElMessageBox,
		ElMessage
	} from 'element-plus'
	import router from "../route/index.js"
	export default {
		name: 'GoodsManage',
		components: {
			Index
		},
		data() {
			return {
				shangpin: [],
				categoryList: [],
				gongying: [],
				goods: {},
				show: false,
				type: '',
				title: '',
				rules: {
					sid: [{
						required: true,
						message: 'Please select Organizer',
						trigger: 'blur'
					}],
					type: [{
						required: true,
						message: 'Please select Crowd Funding Type',
						trigger: 'blur'
					}],
					goodsname: [{
						required: true,
						message: 'Please input Project Name',
						trigger: 'blur'
					}],
					pic: [{
						required: true,
						message: 'Please Input Project Picture',
						trigger: 'blur'
					}],
					price: [{
						required: true,
						message: 'Please input Fundraising amount',
						trigger: 'blur'
					}],
					productiondate: [{
						required: true,
						message: 'Please input Deadline',
						trigger: 'blur'
					}, {
						pattern: /\d{4}-\d{2}-\d{2}/,
						message: '请输入正确格式(yyyy-MM-dd)',
						trigger: 'blur'
					}],
					number: [{
						required: true,
						message: 'Please input Crowd funding Num',
						trigger: 'blur'
					}],
					lirun: [{
						required: true,
						message: 'Please input Project losses',
						trigger: 'blur'
					}],
				}
			}
		},
		created() {
			this.getGoods();
		},
		methods: {
			editGoods(goods) {
				this.$refs[goods].validate(valid => {
					if (valid) {
						// 创建formData实例对象
						let formData = new FormData(document.getElementById("fm"));
						// 把文件InfomationAdd 进如对象
						formData.append('file', document.getElementById("imgs").files[0])
						formData.append('sid', this.goods.sid)
						formData.append('type', this.goods.type)
						formData.append('id', this.goods.id)
						Axios.post('shopmng/api/goods/updateInfo', formData).then(res => {
							if (res.data.affectedRows > 0) {
								ElMessage({
									type: 'success',
									message: 'Change Success',
								});
								this.show = false;
								this.getGoods();
							} else {
								ElMessage({
									type: 'info',
									message: 'Change Fail',
								})
							}
						})
					} else {
						return false
					}
				})

			},
			updateGoods(val) {
				this.getGoodsType();
				this.getSupplier();
				this.show = true;
				this.title = "Change Project Infomation";
				this.type = "update";
				this.goods = val;
				// Axios.post('/shopmng/api/goods/selectOne', {
				// 	'id': val.id
				// }).then(res => {
				// 	this.goods = res.data[0];
				// });
			},
			addGoods(goods) {
				this.$refs[goods].validate(valid => {
				if (valid) {				
					// 创建formData实例对象
					let formData = new FormData(document.getElementById("fm"));
					// 把文件InfomationAdd 进如对象
					formData.append('file', document.getElementById("imgs").files[0])
					formData.append('sid', this.goods.sid)
					formData.append('type', this.goods.type)
			
					// 发送文件Infomation给后端
					Axios.post('/shopmng/api/goods/add', formData)
						.then(res => {
							console.log(res.data);
							if (res.data.affectedRows == 1) {
								ElMessage({
									message: 'Add Success',
									type: 'success',
								});
								this.show = false;
								this.getGoods();
							} else {
								ElMessage.error('Add Fail')
							}
						})
				} else {
					return false
				}
			})
				
			},
			showDialog() {
				this.getGoodsType();
				this.getSupplier();
				//单击时对话框可见
				this.show = true;
				this.title = "Project Infomation";
				this.type = "create";
				this.goods = {};
			},
			getSupplier() { //获取供应商
				Axios.post('/shopmng/api/supplier/selectAll').then(res => {
					this.gongying = res.data;
				});
			},
			getGoodsType() { //获取Crowd Funding Type
				Axios.post('/shopmng/api/type/selectAll').then(res => {
					this.categoryList = res.data;
				});
			},
			getGoods() {
				Axios.post('/shopmng/api/goods/selectAll').then(res => {
					this.shangpin = res.data;
				});
			},
			deleteGoods(obj, index) {
				console.log(index);
				ElMessageBox.confirm(
					'确认Delete 吗？', {
						confirmButtonText: '确认',
						cancelButtonText: '取消',
						type: 'warning',
					}
				).then(() => {
					Axios.post('/shopmng/api/goods/deleteOne', {
						'id': obj.id
					}).then(res => {
						if (res.data.affectedRows == 1) {
							this.getGoods();
							ElMessage({
								message: 'Delete Success',
								type: 'success',
							});
						} else {
							ElMessage({
								message: 'Delete Fail',
							});
						}
					});

				})
			}
		}
	}
</script>

<style>
</style>
